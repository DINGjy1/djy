function f(s) {
    var d = s.options[s.selectedIndex].value;
    if (d != "") {
        open(d, '_blank');
        s.selectedIndex = 0;
        s.blur();
    }
}

function y(s) {
    var d = s.options[s.selectedIndex].value;
    if (d != "") {
        open(d, '_blank');
        s.selectedIndex = 0;
        s.blur();
    }
}