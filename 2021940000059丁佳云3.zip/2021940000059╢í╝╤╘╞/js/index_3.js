p1.onclick = function() {
    p1.style.color = "red";
    alert("p1");
}

p2.onclick = function() {
    var date = new Date();
    h1.innerHTML = formatDate(date);
    alert("p2");
}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
}

p3.onclick = function() {
    p3.classList.add("fn-active");
    alert("p3");
}

p4.onclick = function() {
    p8.remove();
    alert("p4");
}

p5.onclick = function() {
    window.open("https://www.taobao.com");
    alert("p5");
}

p6.onclick = function() {
    ali = document.createElement("li");
    ali.innerHTML = "p9";
    ali.className = "m-item";
    ali.id = "p9";
    ul.appendChild(ali);
    alert("p6");

    p9.onclick = function() {
        alert("p9");
    }
}

p7.onclick = function() {
    document.getElementById("m-box").style.width = screen.width;
    alert("p7");
}

p8.onclick = function() {
    alert("p8");
}